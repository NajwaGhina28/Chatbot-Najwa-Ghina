import hashlib
import mysql.connector

def check_login(username, password):
    # Hubungkan ke database
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password=" ",
        database="tugasakhir"
    )
    cursor = conn.cursor()

    # Enkripsi password yang diketik
    hashed_password = hashlib.md5(password.encode()).hexdigest()

    # Cek apakah user ada
    query = "SELECT * FROM admin WHERE username = %s AND password = %s"
    cursor.execute(query, (username, hashed_password))
    user = cursor.fetchone()

    cursor.close()
    conn.close()

    return user is not None  # True jika login berhasil

def get_admin_id(username):
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password=" ",
        database="tugasakhir"
    )
    cursor = conn.cursor()
    query = "SELECT admin_id FROM admin WHERE username = %s"
    cursor.execute(query, (username,))
    result = cursor.fetchone()
    cursor.close()
    conn.close()

    return result[0] if result else None

