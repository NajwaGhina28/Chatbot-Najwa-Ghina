import mysql.connector

def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password=" ",  # Hati-hati, jangan biarkan spasi di password jika memang kosong
        database="tugasakhir"
    )

# Ambil jumlah dari tabel data
def get_total_data():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM data")
    total = cursor.fetchone()[0]
    cursor.close()
    conn.close()
    return total

# Ambil jumlah dari tabel evaluasi
def get_total_evaluasi():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM evaluasi")
    total = cursor.fetchone()[0]
    cursor.close()
    conn.close()
    return total
