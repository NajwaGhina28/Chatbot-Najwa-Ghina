import mysql.connector
from datetime import datetime  # jika kamu ingin memasukkan timestamp manual

def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password=" ",  # Hati-hati, jangan biarkan spasi di password jika memang kosong
        database="tugasakhir"
    )


# Fungsi untuk mengambil semua data beserta nama admin
def get_all_data():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT data.data_id, data.nama, data.created_at, admin.username AS pembuat
        FROM data
        JOIN admin ON data.admin_id = admin.admin_id
    """)
    data = cursor.fetchall()
    cursor.close()
    conn.close()
    return data


# Hapus data berdasarkan ID
def delete_data(data_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM data WHERE data_id = %s", (data_id,))
    conn.commit()
    cursor.close()
    conn.close()

# Untuk ambil file dari data_id
def get_file_by_id(data_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT data_id, nama, data FROM data WHERE data_id = %s", (data_id,))
    file_record = cursor.fetchone()
    cursor.close()
    conn.close()
    return file_record



# Fungsi untuk menyimpan data dan file .txt
def save_data(nama, file, admin_id):
    conn = get_db_connection()
    cursor = conn.cursor()

    file_data = file.read()

    query = """
        INSERT INTO data (nama, data, admin_id)
        VALUES (%s, %s, %s)
    """
    cursor.execute(query, (nama, file_data, admin_id))
    conn.commit()

    cursor.close()
    conn.close()
