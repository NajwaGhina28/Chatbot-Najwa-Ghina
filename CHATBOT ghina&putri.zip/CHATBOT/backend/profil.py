import mysql.connector
import base64

def get_admin_profile(admin_id):
    db = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="tugasakhir"
    )
    cursor = db.cursor()
    query = "SELECT admin_id, username, foto_profil, fullname, nip FROM admin WHERE admin_id = %s"
    cursor.execute(query, (admin_id,))
    result = cursor.fetchone()

    if result:
        admin_id, username, foto_blob, fullname, nip = result
        foto_base64 = base64.b64encode(foto_blob).decode('utf-8') if foto_blob else None
        cursor.close()
        db.close()
        return {
            "admin_id": admin_id,
            "username": username,
            "fullname": fullname,
            "nip": nip,
            "foto_base64": foto_base64
        }
    else:
        cursor.close()
        db.close()
        return None


def update_admin_profile(admin_id, fullname, username, nip, foto_bytes=None):
    db = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="tugasakhir"
    )
    cursor = db.cursor()

    if foto_bytes:
        query = """
            UPDATE admin SET fullname = %s, username = %s, nip = %s, foto_profil = %s
            WHERE admin_id = %s
        """
        values = (fullname, username, nip, foto_bytes, admin_id)
    else:
        query = """
            UPDATE admin SET fullname = %s, username = %s, nip = %s
            WHERE admin_id = %s
        """
        values = (fullname, username, nip, admin_id)

    cursor.execute(query, values)
    db.commit()
    cursor.close()
    db.close()
