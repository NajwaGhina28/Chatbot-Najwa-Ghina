import mysql.connector

# Fungsi untuk menghubungkan ke database
def get_db_connection():
    return mysql.connector.connect(
        host="localhost",     # Sesuaikan dengan host database Anda
        user="root",          # Sesuaikan dengan username database Anda
        password="",         # Sesuaikan dengan password database Anda
        database="tugasakhir" # Sesuaikan dengan nama database Anda
    )

# Fungsi untuk mengambil data evaluasi
# Fungsi untuk mengambil data evaluasi
def get_all_evaluasi():
    conn = get_db_connection()  # Membuka koneksi ke database
    cursor = conn.cursor(dictionary=True)  # Menyiapkan cursor dengan dictionary
    cursor.execute("SELECT * FROM evaluasi")  # Query untuk mengambil seluruh data evaluasi
    evaluasi_list = cursor.fetchall()  # Mengambil seluruh hasil query
    cursor.close()
    conn.close()  # Menutup koneksi setelah query selesai
    
    # Cek hasil query
    for evaluasi in evaluasi_list:
        print(f"Evaluasi ID: {evaluasi['evaluasi_id']}, Pertanyaan: {evaluasi['pertanyaan']}, Jawaban: {evaluasi['jawaban']}")  # Mengganti 'id' menjadi 'evaluasi_id'
    
    return evaluasi_list  # Mengembalikan data evaluasi

# Hapus data evaluasi berdasarkan ID
def delete_evaluasi(evaluasi_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM evaluasi WHERE evaluasi_id = %s", (evaluasi_id,))
    conn.commit()
    cursor.close()
    conn.close()
